# Safety Goggles > 2023-05-24 9:24am
https://universe.roboflow.com/hoang-nguyen-4itwr/safety-goggles-zp28p

Provided by a Roboflow user
License: CC BY 4.0

